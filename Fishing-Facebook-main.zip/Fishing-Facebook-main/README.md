# GHOSTEPROG
# WARNING
Please dont use this script to hack someone's ID
# Instructions
1. Edit do_action.php and replace YOUR_EMAIL_ADDRESS with the email you want to recieve access.
Upload it to a PHP supported web server.
